package com.securescanhub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * SecureScan Hub - Main Application Entry Point
 * A production-ready security scanning platform with JWT authentication,
 * malware detection, and crawler threat analysis.
 *
 * @author SecureScan Hub Team
 * @version 1.0.0
 */
@SpringBootApplication
public class SecureScanHubApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecureScanHubApplication.class, args);
        System.out.println("""
                ╔══════════════════════════════════════╗
                ║       SecureScan Hub Started!        ║
                ║   Navigate to: http://localhost:8080  ║
                ╚══════════════════════════════════════╝
                """);
    }
}

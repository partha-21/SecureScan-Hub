package com.securescanhub.controller;

import com.securescanhub.model.dto.ApiResponse;
import com.securescanhub.model.dto.AuthResponse;
import com.securescanhub.model.dto.LoginRequest;
import com.securescanhub.model.dto.RegisterRequest;
import com.securescanhub.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * AuthController - Handles user registration and login (public endpoints).
 *
 * POST /auth/register  → Register a new user
 * POST /auth/login     → Authenticate and receive JWT token
 */
@Slf4j
@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    /**
     * Registers a new user account.
     * Validates all fields using @Valid before passing to service.
     */
    @PostMapping("/register")
    public ResponseEntity<ApiResponse<String>> register(
            @Valid @RequestBody RegisterRequest request) {
        log.info("POST /auth/register for email: {}", request.getEmail());
        String message = authService.register(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(message, null));
    }

    /**
     * Authenticates user credentials and returns a signed JWT token.
     */
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> login(
            @Valid @RequestBody LoginRequest request) {
        log.info("POST /auth/login for email: {}", request.getEmail());
        AuthResponse authResponse = authService.login(request);
        return ResponseEntity.ok(ApiResponse.success("Login successful", authResponse));
    }
}

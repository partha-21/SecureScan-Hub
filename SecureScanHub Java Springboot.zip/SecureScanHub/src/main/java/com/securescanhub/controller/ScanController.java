package com.securescanhub.controller;

import com.securescanhub.model.dto.*;
import com.securescanhub.service.CrawlerScanService;
import com.securescanhub.service.MalwareScanService;
import com.securescanhub.service.ScanHistoryService;
import com.securescanhub.util.SecurityContextUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * ScanController - All protected scan endpoints. Requires valid JWT.
 *
 * POST /scan/malware   → Scan text or file for malware
 * POST /scan/crawler   → Crawl a URL with multithreading
 * GET  /scan/history   → Retrieve authenticated user's scan history
 */
@Slf4j
@RestController
@RequestMapping("/scan")
@RequiredArgsConstructor
public class ScanController {

    private final MalwareScanService malwareScanService;
    private final CrawlerScanService crawlerScanService;
    private final ScanHistoryService scanHistoryService;

    /**
     * Scans submitted text for malicious patterns.
     * Accepts JSON body: { "textInput": "..." }
     */
    @PostMapping("/malware")
    public ResponseEntity<ApiResponse<ScanResponse>> scanMalwareText(
            @Valid @RequestBody MalwareScanRequest request) {
        String userEmail = SecurityContextUtil.getCurrentUserEmail();
        log.info("POST /scan/malware (text) by: {}", userEmail);

        if (request.getTextInput() == null || request.getTextInput().isBlank()) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Text input is required"));
        }

        ScanResponse result = malwareScanService.scanText(request.getTextInput(), userEmail);
        return ResponseEntity.ok(ApiResponse.success("Scan complete", result));
    }

    /**
     * Scans an uploaded file for malicious content.
     * Accepts multipart/form-data with field "file".
     */
    @PostMapping(value = "/malware/file", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse<ScanResponse>> scanMalwareFile(
            @RequestParam("file") MultipartFile file) {
        String userEmail = SecurityContextUtil.getCurrentUserEmail();
        log.info("POST /scan/malware/file [{}] by: {}", file.getOriginalFilename(), userEmail);

        if (file.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Uploaded file is empty"));
        }

        ScanResponse result = malwareScanService.scanFile(file, userEmail);
        return ResponseEntity.ok(ApiResponse.success("File scan complete", result));
    }

    /**
     * Initiates a multi-threaded crawler scan on the given URL.
     * Accepts JSON body: { "url": "https://..." }
     */
    @PostMapping("/crawler")
    public ResponseEntity<ApiResponse<ScanResponse>> scanCrawler(
            @Valid @RequestBody CrawlerScanRequest request) {
        String userEmail = SecurityContextUtil.getCurrentUserEmail();
        log.info("POST /scan/crawler [{}] by: {}", request.getUrl(), userEmail);

        ScanResponse result = crawlerScanService.crawlUrl(request.getUrl(), userEmail);
        return ResponseEntity.ok(ApiResponse.success("Crawler scan complete", result));
    }

    /**
     * Returns the full scan history for the authenticated user.
     */
    @GetMapping("/history")
    public ResponseEntity<ApiResponse<List<HistoryResponse>>> getHistory() {
        String userEmail = SecurityContextUtil.getCurrentUserEmail();
        log.info("GET /scan/history by: {}", userEmail);

        List<HistoryResponse> history = scanHistoryService.getUserHistory(userEmail);
        return ResponseEntity.ok(ApiResponse.success(
                "Fetched " + history.size() + " record(s)", history));
    }
}

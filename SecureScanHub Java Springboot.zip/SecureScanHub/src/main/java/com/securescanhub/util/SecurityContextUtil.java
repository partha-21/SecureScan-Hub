package com.securescanhub.util;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Utility class to extract the authenticated user's email from the
 * Spring Security context (populated by JWT filter).
 */
public class SecurityContextUtil {

    private SecurityContextUtil() {}

    /**
     * Returns the email of the currently authenticated user.
     *
     * @return email string
     * @throws IllegalStateException if no authenticated user is found
     */
    public static String getCurrentUserEmail() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new IllegalStateException("No authenticated user found");
        }
        Object principal = authentication.getPrincipal();
        if (principal instanceof UserDetails userDetails) {
            return userDetails.getUsername(); // username == email in our setup
        }
        return principal.toString();
    }
}

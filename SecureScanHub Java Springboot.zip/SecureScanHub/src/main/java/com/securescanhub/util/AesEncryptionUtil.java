package com.securescanhub.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

/**
 * AES Encryption Utility - Provides AES/ECB/PKCS5Padding encrypt/decrypt.
 * Used to protect sensitive fields like the security PIN before DB storage.
 */
@Slf4j
@Component
public class AesEncryptionUtil {

    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/ECB/PKCS5Padding";

    @Value("${app.aes.secret}")
    private String aesSecret;

    /**
     * Encrypts plaintext using AES and returns Base64-encoded ciphertext.
     *
     * @param plaintext raw string to encrypt
     * @return Base64-encoded encrypted string
     */
    public String encrypt(String plaintext) {
        try {
            SecretKeySpec keySpec = getKeySpec();
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, keySpec);
            byte[] encrypted = cipher.doFinal(plaintext.getBytes());
            return Base64.getEncoder().encodeToString(encrypted);
        } catch (Exception e) {
            log.error("AES encryption failed: {}", e.getMessage());
            throw new RuntimeException("Encryption error", e);
        }
    }

    /**
     * Decrypts a Base64-encoded AES ciphertext back to plaintext.
     *
     * @param ciphertext Base64-encoded encrypted string
     * @return decrypted plaintext
     */
    public String decrypt(String ciphertext) {
        try {
            SecretKeySpec keySpec = getKeySpec();
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, keySpec);
            byte[] decoded = Base64.getDecoder().decode(ciphertext);
            return new String(cipher.doFinal(decoded));
        } catch (Exception e) {
            log.error("AES decryption failed: {}", e.getMessage());
            throw new RuntimeException("Decryption error", e);
        }
    }

    /**
     * Builds a 16-byte AES SecretKeySpec from the configured secret.
     */
    private SecretKeySpec getKeySpec() {
        // Pad or truncate to exactly 16 bytes (AES-128)
        byte[] keyBytes = new byte[16];
        byte[] secretBytes = aesSecret.getBytes();
        System.arraycopy(secretBytes, 0, keyBytes, 0, Math.min(secretBytes.length, 16));
        return new SecretKeySpec(keyBytes, ALGORITHM);
    }
}

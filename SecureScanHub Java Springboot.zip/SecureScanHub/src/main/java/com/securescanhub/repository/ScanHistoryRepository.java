package com.securescanhub.repository;

import com.securescanhub.model.entity.ScanHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for ScanHistory entity - supports user-specific history queries.
 */
@Repository
public interface ScanHistoryRepository extends JpaRepository<ScanHistory, Long> {

    /**
     * Retrieve all scan records for a given user email, ordered by newest first.
     */
    List<ScanHistory> findByUserEmailOrderByTimestampDesc(String userEmail);

    /**
     * Count scans by user and action type.
     */
    long countByUserEmailAndActionType(String userEmail, ScanHistory.ActionType actionType);
}

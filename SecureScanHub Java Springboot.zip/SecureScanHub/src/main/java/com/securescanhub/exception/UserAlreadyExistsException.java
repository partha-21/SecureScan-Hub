package com.securescanhub.exception;

/**
 * Thrown when a user tries to register with an already-taken email.
 */
public class UserAlreadyExistsException extends RuntimeException {
    public UserAlreadyExistsException(String message) {
        super(message);
    }
}

package com.securescanhub.service;

import com.securescanhub.model.dto.ScanResponse;
import com.securescanhub.model.entity.ScanHistory;
import com.securescanhub.repository.ScanHistoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * CrawlerScanService - Simulates multi-threaded URL crawling to detect
 * suspicious access patterns (repeated hits from the same thread = bot behaviour).
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CrawlerScanService {

    private final ScanHistoryRepository scanHistoryRepository;

    @Value("${app.crawler.thread-pool-size:5}")
    private int threadPoolSize;

    @Value("${app.crawler.hit-threshold:3}")
    private int hitThreshold;

    public ScanResponse crawlUrl(String url, String userEmail) {
        log.info("Crawler scan initiated for URL: {} by: {}", url, userEmail);

        ExecutorService executor = Executors.newFixedThreadPool(threadPoolSize);
        ConcurrentHashMap<String, AtomicInteger> hitMap = new ConcurrentHashMap<>();
        List<Future<String>> futures = new ArrayList<>();

        int totalTasks = threadPoolSize * 2;
        for (int i = 0; i < totalTasks; i++) {
            futures.add(executor.submit(() -> {
                String threadName = Thread.currentThread().getName();
                hitMap.computeIfAbsent(threadName, k -> new AtomicInteger(0)).incrementAndGet();
                try {
                    Thread.sleep(java.util.concurrent.ThreadLocalRandom.current().nextLong(50, 200));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                int hits = hitMap.get(threadName).get();
                log.debug("Thread [{}] accessed {} | total hits: {}", threadName, url, hits);
                return String.format("Thread=%s | Hits=%d", threadName, hits);
            }));
        }

        for (Future<String> future : futures) {
            try { future.get(5, TimeUnit.SECONDS); }
            catch (Exception e) { log.warn("Crawler task exception: {}", e.getMessage()); }
        }

        executor.shutdown();
        try {
            if (!executor.awaitTermination(10, TimeUnit.SECONDS)) executor.shutdownNow();
        } catch (InterruptedException e) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }

        List<String> suspiciousThreads = new ArrayList<>();
        StringBuilder details = new StringBuilder();
        details.append("URL: ").append(url).append("\n");
        details.append("Scan Time: ").append(LocalDateTime.now()).append("\n\n");
        details.append("=== Thread Activity Log ===\n");

        hitMap.forEach((threadName, count) -> {
            int hits = count.get();
            String flag = hits >= hitThreshold ? "  ⚠ SUSPICIOUS" : "";
            details.append(String.format("  %-40s → %d hit(s)%s%n", threadName, hits, flag));
            log.info("Crawler thread | {}: {} hits", threadName, hits);
            if (hits >= hitThreshold) suspiciousThreads.add(threadName + " (" + hits + " hits)");
        });

        String result;
        ScanResponse response;

        if (!suspiciousThreads.isEmpty()) {
            result = "Suspicious Activity";
            details.append("\n⚠ Suspicious threads: ").append(String.join(", ", suspiciousThreads));
            response = ScanResponse.builder()
                    .status("Suspicious Activity")
                    .subject(url)
                    .details(details.toString())
                    .scanType("CRAWLER_SCAN")
                    .timestamp(LocalDateTime.now())
                    .build();
            log.warn("Suspicious crawler activity detected for URL: {}", url);
        } else {
            result = "Safe";
            details.append("\n✓ No suspicious activity detected.");
            response = ScanResponse.builder()
                    .status("Safe")
                    .subject(url)
                    .details(details.toString())
                    .scanType("CRAWLER_SCAN")
                    .timestamp(LocalDateTime.now())
                    .build();
        }

        scanHistoryRepository.save(ScanHistory.builder()
                .userEmail(userEmail)
                .actionType(ScanHistory.ActionType.CRAWLER_SCAN)
                .subject(url)
                .result(result)
                .details(details.toString())
                .build());

        return response;
    }
}

package com.securescanhub.service;

import com.securescanhub.exception.UserAlreadyExistsException;
import com.securescanhub.model.dto.AuthResponse;
import com.securescanhub.model.dto.LoginRequest;
import com.securescanhub.model.dto.RegisterRequest;
import com.securescanhub.model.entity.User;
import com.securescanhub.repository.UserRepository;
import com.securescanhub.security.jwt.JwtUtil;
import com.securescanhub.util.AesEncryptionUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Authentication Service - Handles user registration and login.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AesEncryptionUtil aesEncryptionUtil;
    private final AuthenticationManager authenticationManager;
    private final UserDetailsService userDetailsService;
    private final JwtUtil jwtUtil;

    /**
     * Registers a new user after validating email uniqueness.
     * Password is BCrypt-hashed; PIN is AES-encrypted before saving.
     *
     * @param request registration payload
     * @return success message
     */
    @Transactional
    public String register(RegisterRequest request) {
        log.info("Registration attempt for email: {}", request.getEmail());

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new UserAlreadyExistsException(
                    "Email already registered: " + request.getEmail());
        }

        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail().toLowerCase())
                .password(passwordEncoder.encode(request.getPassword()))
                .securityPin(aesEncryptionUtil.encrypt(request.getSecurityPin()))
                .role(User.Role.USER)
                .build();

        userRepository.save(user);
        log.info("User registered successfully: {}", user.getEmail());
        return "Registration successful! Please log in.";
    }

    /**
     * Authenticates a user and returns a JWT token.
     *
     * @param request login credentials
     * @return AuthResponse containing JWT and user info
     */
    public AuthResponse login(LoginRequest request) {
        log.info("Login attempt for email: {}", request.getEmail());

        // Throws BadCredentialsException if authentication fails
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail().toLowerCase(),
                        request.getPassword()
                )
        );

        UserDetails userDetails = userDetailsService.loadUserByUsername(
                request.getEmail().toLowerCase());
        String token = jwtUtil.generateToken(userDetails);

        User user = userRepository.findByEmail(request.getEmail().toLowerCase())
                .orElseThrow();

        log.info("User logged in: {}", user.getEmail());
        return AuthResponse.success(token, user.getEmail(), user.getName(), user.getRole().name());
    }
}

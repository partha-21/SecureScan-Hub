package com.securescanhub.service;

import com.securescanhub.model.dto.HistoryResponse;
import com.securescanhub.repository.ScanHistoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * ScanHistoryService - Retrieves scan history records for the authenticated user.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ScanHistoryService {

    private final ScanHistoryRepository scanHistoryRepository;

    /**
     * Returns all scan history for a given user email, newest first.
     */
    public List<HistoryResponse> getUserHistory(String userEmail) {
        log.debug("Fetching scan history for: {}", userEmail);
        return scanHistoryRepository
                .findByUserEmailOrderByTimestampDesc(userEmail)
                .stream()
                .map(HistoryResponse::from)
                .collect(Collectors.toList());
    }
}

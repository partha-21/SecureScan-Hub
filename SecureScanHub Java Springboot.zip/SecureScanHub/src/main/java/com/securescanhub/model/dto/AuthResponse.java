package com.securescanhub.model.dto;

import lombok.*;

/**
 * DTO returned after successful authentication.
 * Contains JWT token and basic user info.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuthResponse {

    private String token;
    private String tokenType;
    private String email;
    private String name;
    private String role;
    private String message;

    /** Convenience factory for a successful auth response */
    public static AuthResponse success(String token, String email, String name, String role) {
        return AuthResponse.builder()
                .token(token)
                .tokenType("Bearer")
                .email(email)
                .name(name)
                .role(role)
                .message("Authentication successful")
                .build();
    }
}

package com.securescanhub.model.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.*;

/**
 * DTO for crawler scan URL input.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CrawlerScanRequest {

    @NotBlank(message = "URL is required")
    @Pattern(regexp = "^(https?://).+", message = "URL must start with http:// or https://")
    private String url;
}

package com.securescanhub.model.dto;

import com.securescanhub.model.entity.ScanHistory;
import lombok.*;

import java.time.LocalDateTime;

/**
 * DTO for returning scan history entries to the client.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HistoryResponse {

    private Long id;
    private String actionType;
    private String subject;
    private String result;
    private String details;
    private LocalDateTime timestamp;

    /** Map entity to DTO */
    public static HistoryResponse from(ScanHistory history) {
        return HistoryResponse.builder()
                .id(history.getId())
                .actionType(history.getActionType().name())
                .subject(history.getSubject())
                .result(history.getResult())
                .details(history.getDetails())
                .timestamp(history.getTimestamp())
                .build();
    }
}

package com.securescanhub.model.dto;

import lombok.*;

import java.time.LocalDateTime;

/**
 * Generic DTO returned after any scan operation.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ScanResponse {

    private String status;       // "Safe" | "Threat Detected" | "Suspicious Activity"
    private String subject;      // What was scanned (text snippet / URL / filename)
    private String details;      // Detailed findings
    private String scanType;     // MALWARE_SCAN | CRAWLER_SCAN
    private LocalDateTime timestamp;

    public static ScanResponse safe(String subject, String scanType) {
        return ScanResponse.builder()
                .status("Safe")
                .subject(subject)
                .details("No threats found.")
                .scanType(scanType)
                .timestamp(LocalDateTime.now())
                .build();
    }

    public static ScanResponse threat(String subject, String details, String scanType) {
        return ScanResponse.builder()
                .status("Threat Detected")
                .subject(subject)
                .details(details)
                .scanType(scanType)
                .timestamp(LocalDateTime.now())
                .build();
    }
}

package com.securescanhub.model.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/**
 * ScanHistory Entity - Tracks every scan action performed by a user.
 * Used for audit trail and history retrieval.
 */
@Entity
@Table(name = "scan_history")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ScanHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Email of the user who performed the scan */
    @Column(nullable = false)
    private String userEmail;

    /** Type of scan performed */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ActionType actionType;

    /** Input subject: filename, URL, or text snippet (first 255 chars) */
    @Column(length = 512)
    private String subject;

    /** Scan result: Safe / Threat Detected / Suspicious Activity / etc. */
    @Column(nullable = false)
    private String result;

    /** Additional details (JSON or plain text) */
    @Column(columnDefinition = "TEXT")
    private String details;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime timestamp;

    public enum ActionType {
        MALWARE_SCAN, CRAWLER_SCAN
    }
}

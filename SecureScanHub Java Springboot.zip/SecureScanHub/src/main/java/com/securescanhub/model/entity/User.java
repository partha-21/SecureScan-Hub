package com.securescanhub.model.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * User Entity - Represents a registered user in SecureScan Hub.
 * Password is stored as BCrypt hash; PIN as AES-encrypted value.
 */
@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Full name of the user */
    @Column(nullable = false)
    private String name;

    /** Unique email used as the login identifier */
    @Column(nullable = false, unique = true)
    private String email;

    /** BCrypt-encrypted password */
    @Column(nullable = false)
    private String password;

    /** AES-encrypted 4-digit security PIN */
    @Column(nullable = false)
    private String securityPin;

    /** Role for RBAC: USER or ADMIN */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private Role role = Role.USER;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    public enum Role {
        USER, ADMIN
    }
}

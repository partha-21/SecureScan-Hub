package com.securescanhub.model.dto;

import jakarta.validation.constraints.*;
import lombok.*;

/**
 * DTO for user registration request payload.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RegisterRequest {

    @NotBlank(message = "Name is required")
    @Size(min = 2, max = 100, message = "Name must be between 2-100 characters")
    private String name;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;

    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String password;

    @NotBlank(message = "Security PIN is required")
    @Pattern(regexp = "\\d{4}", message = "Security PIN must be exactly 4 digits")
    private String securityPin;
}

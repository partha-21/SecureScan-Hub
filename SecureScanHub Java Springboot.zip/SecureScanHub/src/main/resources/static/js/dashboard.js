/**
 * dashboard.js — SecureScan Hub Dashboard Logic
 * Handles: panel navigation, malware scan, crawler scan, history
 */

// ── Init ─────────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
    const name  = localStorage.getItem('userName')  || 'User';
    const email = localStorage.getItem('userEmail') || '';

    const nameEl  = document.getElementById('sidebarName');
    const emailEl = document.getElementById('sidebarEmail');
    const avatarEl = document.getElementById('userAvatar');

    if (nameEl)  nameEl.textContent  = name;
    if (emailEl) emailEl.textContent = email;
    if (avatarEl) avatarEl.textContent = name.charAt(0).toUpperCase();
});

// ── Panel Navigation ──────────────────────────────────────────────────────────

const PANEL_TITLES = {
    malware: ['Malware Scanner',        'Detect threats in text or files'],
    crawler: ['Crawler Thread Analyser','Simulate multi-threaded URL crawling'],
    history: ['Scan History',           'Your complete activity log'],
};

function showPanel(name, linkEl) {
    // Hide all panels
    document.querySelectorAll('.panel').forEach(p => {
        p.classList.add('hidden');
        p.classList.remove('active');
    });
    // Show target
    const panel = document.getElementById(`panel-${name}`);
    if (panel) { panel.classList.remove('hidden'); panel.classList.add('active'); }

    // Update active nav
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    if (linkEl) linkEl.classList.add('active');

    // Update header
    const [title, subtitle] = PANEL_TITLES[name] || ['Dashboard', ''];
    document.getElementById('panelTitle').textContent   = title;
    document.getElementById('panelSubtitle').textContent = subtitle;

    return false; // prevent anchor scroll
}

// ── Malware — Text Scan ───────────────────────────────────────────────────────

async function scanMalwareText() {
    const text = document.getElementById('malwareText').value.trim();
    if (!text) { showAlert('Please enter text to scan.', 'error', 'malwareTextAlert'); return; }

    showAlert('Scanning…', 'info', 'malwareTextAlert');
    document.getElementById('malwareTextResult').classList.add('hidden');

    try {
        const res = await fetch('/scan/malware', {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({ textInput: text })
        });
        if (res.status === 403 || res.status === 401) { logout(); return; }
        const data = await res.json();
        if (data.success) {
            renderScanResult('malwareTextResult', data.data);
            hideAlert('malwareTextAlert');
        } else {
            showAlert(data.message || 'Scan failed.', 'error', 'malwareTextAlert');
        }
    } catch (e) {
        showAlert('Server error: ' + e.message, 'error', 'malwareTextAlert');
    }
}

// ── Malware — File Scan ───────────────────────────────────────────────────────

function updateFileName(input) {
    const sf = document.getElementById('selectedFile');
    if (input.files.length > 0) {
        sf.textContent = '📎 ' + input.files[0].name + ' (' + formatBytes(input.files[0].size) + ')';
        sf.classList.remove('hidden');
    }
}

async function scanMalwareFile() {
    const fileInput = document.getElementById('fileInput');
    if (!fileInput.files.length) {
        showAlert('Please select a file first.', 'error', 'malwareFileAlert'); return;
    }

    showAlert('Uploading & scanning…', 'info', 'malwareFileAlert');
    document.getElementById('malwareFileResult').classList.add('hidden');

    const formData = new FormData();
    formData.append('file', fileInput.files[0]);

    try {
        const res = await fetch('/scan/malware/file', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${getToken()}` },
            body: formData
        });
        if (res.status === 403 || res.status === 401) { logout(); return; }
        const data = await res.json();
        if (data.success) {
            renderScanResult('malwareFileResult', data.data);
            hideAlert('malwareFileAlert');
        } else {
            showAlert(data.message || 'Scan failed.', 'error', 'malwareFileAlert');
        }
    } catch (e) {
        showAlert('Server error: ' + e.message, 'error', 'malwareFileAlert');
    }
}

// ── Crawler Scan ──────────────────────────────────────────────────────────────

async function scanCrawler() {
    const url = document.getElementById('crawlerUrl').value.trim();
    if (!url) { showAlert('Please enter a URL.', 'error', 'crawlerAlert'); return; }
    if (!url.startsWith('http')) { showAlert('URL must start with http:// or https://', 'error', 'crawlerAlert'); return; }

    hideAlert('crawlerAlert');
    document.getElementById('crawlerResult').classList.add('hidden');
    const progress = document.getElementById('crawlerProgress');
    progress.classList.remove('hidden');
    // Reset animation
    const fill = document.getElementById('progressFill');
    fill.style.animation = 'none';
    fill.offsetHeight; // reflow
    fill.style.animation = '';

    try {
        const res = await fetch('/scan/crawler', {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({ url })
        });
        if (res.status === 403 || res.status === 401) { logout(); return; }
        const data = await res.json();
        progress.classList.add('hidden');
        if (data.success) {
            renderScanResult('crawlerResult', data.data);
        } else {
            showAlert(data.message || 'Crawler scan failed.', 'error', 'crawlerAlert');
        }
    } catch (e) {
        progress.classList.add('hidden');
        showAlert('Server error: ' + e.message, 'error', 'crawlerAlert');
    }
}

// ── Scan History ──────────────────────────────────────────────────────────────

async function loadHistory() {
    document.getElementById('historyContent').innerHTML = '<p class="loading-text">⟳ Loading history…</p>';

    try {
        const res = await fetch('/scan/history', {
            headers: { 'Authorization': `Bearer ${getToken()}` }
        });
        if (res.status === 403 || res.status === 401) { logout(); return; }
        const data = await res.json();

        if (!data.success || !data.data.length) {
            document.getElementById('historyContent').innerHTML =
                '<p class="loading-text">No scan history yet. Run a malware or crawler scan!</p>';
            return;
        }

        const rows = data.data.map(h => {
            const statusClass = h.result === 'Safe' ? 'status-safe'
                : h.result === 'Threat Detected'    ? 'status-threat'
                : 'status-suspicious';
            return `<tr>
                <td>${formatDate(h.timestamp)}</td>
                <td><span class="badge">${h.actionType.replace('_', ' ')}</span></td>
                <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${esc(h.subject)}">${esc(h.subject)}</td>
                <td><span class="status-badge ${statusClass}">${esc(h.result)}</span></td>
            </tr>`;
        }).join('');

        document.getElementById('historyContent').innerHTML = `
            <table class="history-table">
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>Type</th>
                        <th>Subject</th>
                        <th>Result</th>
                    </tr>
                </thead>
                <tbody>${rows}</tbody>
            </table>`;
    } catch (e) {
        document.getElementById('historyContent').innerHTML =
            `<p class="loading-text" style="color:var(--danger)">Failed to load history: ${e.message}</p>`;
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function renderScanResult(boxId, scanData) {
    const box = document.getElementById(boxId);
    if (!box) return;

    const isSafe       = scanData.status === 'Safe';
    const isThreat     = scanData.status === 'Threat Detected';
    const isSuspicious = scanData.status === 'Suspicious Activity';

    const cssClass = isSafe ? 'safe' : isThreat ? 'threat' : isSuspicious ? 'warning' : 'info';
    const icon     = isSafe ? '✅' : isThreat ? '🚨' : isSuspicious ? '⚠️' : 'ℹ️';

    box.className = `result-box ${cssClass}`;
    box.innerHTML = `<strong>${icon} ${scanData.status}</strong>\n\n${esc(scanData.details || '')}`;
    box.classList.remove('hidden');
}

function formatDate(isoStr) {
    if (!isoStr) return '—';
    try {
        return new Date(isoStr).toLocaleString();
    } catch { return isoStr; }
}

function formatBytes(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1048576).toFixed(1) + ' MB';
}

function esc(str) {
    if (!str) return '';
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

/**
 * app.js — Shared utility functions for SecureScan Hub frontend
 */

function showAlert(message, type = 'info', boxId = 'alertBox') {
    const box = document.getElementById(boxId);
    if (!box) return;
    box.className = `alert ${type}`;
    box.textContent = message;
    box.classList.remove('hidden');
    if (type === 'success') {
        setTimeout(() => box.classList.add('hidden'), 4000);
    }
}

function hideAlert(boxId = 'alertBox') {
    const box = document.getElementById(boxId);
    if (box) box.classList.add('hidden');
}

function setBtnLoading(loading, btnId = null) {
    const btn = btnId
        ? document.getElementById(btnId)
        : document.querySelector('.btn-primary');
    if (!btn) return;
    btn.disabled = loading;
    const text = btn.querySelector('.btn-text');
    const spinner = btn.querySelector('.btn-spinner');
    if (text) text.textContent = loading ? 'Processing…' : btn.dataset.label || text.textContent;
    if (spinner) spinner.classList.toggle('hidden', !loading);
}

function getToken() {
    return localStorage.getItem('token');
}

function authHeaders() {
    return {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${getToken()}`
    };
}

function logout() {
    localStorage.clear();
    window.location.href = '/login';
}

// Guard all dashboard pages
if (window.location.pathname === '/dashboard') {
    if (!getToken()) {
        window.location.href = '/login';
    }
}
